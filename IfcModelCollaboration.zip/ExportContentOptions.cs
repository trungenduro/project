﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ExportContentOptions
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public enum ExportContentOptions
  {
    Filter,
    All,
    Selected,
    List,
  }
}
