﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.SelectionOptions
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public class SelectionOptions
  {
    public SelectionOptions(ExportContentOptions content, string translatedContent)
    {
      this.Content = content;
      this.TranslatedContent = translatedContent;
    }

    public ExportContentOptions Content { get; set; }

    public string TranslatedContent { get; set; }
  }
}
