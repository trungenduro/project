﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.XmlHandler
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System.Data;
using System.Diagnostics;
using System.IO;

namespace IfcModelCollaboration
{
  internal class XmlHandler
  {
    internal bool WriteDataTableToXml(string file, DataTable table)
    {
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(file))
          table.WriteXml((TextWriter) streamWriter);
      }
      catch (ConstraintException ex)
      {
        Trace.Write((object) ex);
        return false;
      }
      return true;
    }

    internal bool WriteDataSetToXml(string file, DataSet set)
    {
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(file))
          set.WriteXml((TextWriter) streamWriter);
      }
      catch (ConstraintException ex)
      {
        Trace.Write((object) ex);
        return false;
      }
      return true;
    }

    internal bool ReadXmlToDataSet(string file, out DataSet dataSet)
    {
      dataSet = new DataSet();
      if (!File.Exists(file))
        return false;
      try
      {
        int num = (int) dataSet.ReadXml(file);
      }
      catch
      {
        return false;
      }
      return true;
    }

    internal bool ReadXmlToDataTable(string file, string tableName, out DataTable dataTable)
    {
      dataTable = new DataTable(tableName);
      DataSet dataSet;
      if (!File.Exists(file) || !this.ReadXmlToDataSet(file, out dataSet) || (dataSet == null || dataSet.Tables[tableName] == null))
        return false;
      dataTable = dataSet.Tables[tableName];
      return true;
    }
  }
}
