﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.Tuple
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public static class Tuple
  {
    public static Tuple<T1, T2> New<T1, T2>(T1 first, T2 second)
    {
      return new Tuple<T1, T2>(first, second);
    }
  }
}
