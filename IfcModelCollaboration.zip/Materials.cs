﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.Materials
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace IfcModelCollaboration
{
  public class Materials
  {
    private readonly List<string> header = new List<string>()
    {
      "//Tekla Structures;PDMS"
    };
    public const string MaterialsXml = "Materials.xml";

    internal Dictionary<string, string> GetMaterialsDictionary(
      string folder,
      ref ImportData importData)
    {
      string str = folder + "\\Materials.xml";
      if (!File.Exists(str))
      {
        importData.Errors.ErrorCode = ErrorCode.FileDoesNotExist;
        importData.Errors.ErrorInfo = "Materials.xml:" + str;
        return (Dictionary<string, string>) null;
      }
      DataTable dataTable;
      if (!new XmlHandler().ReadXmlToDataTable(str, "MaterialTypes", out dataTable) || dataTable == null)
        return (Dictionary<string, string>) null;
      return this.ConvertMaterialTableToDictionary(dataTable);
    }

    internal bool GetMaterialMapping(
      string materialMappingFile,
      ref Dictionary<string, string> materialMapping,
      out Errors errors)
    {
      errors = new Errors();
      bool flag = true;
      if (!File.Exists(materialMappingFile))
      {
        errors.ErrorCode = ErrorCode.FileDoesNotExist;
        errors.ErrorInfo = materialMappingFile;
        return false;
      }
      try
      {
        using (StreamReader streamReader = new StreamReader(materialMappingFile))
        {
          string str1;
          while ((str1 = streamReader.ReadLine()) != null)
          {
            str1.TrimStart();
            str1.TrimEnd();
            if (!str1.StartsWith("/"))
            {
              string[] strArray = str1.Split(';');
              if (strArray.Length == 2)
              {
                string key = strArray[0];
                try
                {
                  string str2 = strArray[1];
                  key.TrimEnd();
                  str2.TrimStart();
                  if (!materialMapping.ContainsKey(key))
                    materialMapping.Add(key, str2);
                }
                catch (Exception ex)
                {
                  errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
                  errors.ErrorInfo = key;
                  flag = false;
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        errors.ErrorCode = ErrorCode.ReadingOfDataFailed;
        flag = false;
      }
      return flag;
    }

    internal bool SaveMaterialMapping(
      string materialMappingFile,
      Dictionary<string, string> materialMapping,
      string header,
      out Errors errors)
    {
      errors = new Errors();
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(materialMappingFile))
        {
          foreach (string str in this.header)
            streamWriter.WriteLine(str);
          if (materialMapping != null)
          {
            foreach (KeyValuePair<string, string> keyValuePair in materialMapping)
              streamWriter.WriteLine(keyValuePair.Key + ";" + keyValuePair.Value);
          }
        }
      }
      catch (Exception ex)
      {
        errors.ErrorCode = ErrorCode.FileCreationFailed;
        return false;
      }
      return true;
    }

    private Dictionary<string, string> ConvertMaterialTableToDictionary(
      DataTable dataTable)
    {
      Dictionary<string, string> dictionary = new Dictionary<string, string>();
      foreach (DataRow row in (InternalDataCollectionBase) dataTable.Rows)
      {
        try
        {
          dictionary.Add(row["Grade"].ToString(), row["Type"].ToString());
        }
        catch (Exception ex)
        {
        }
      }
      return dictionary;
    }
  }
}
