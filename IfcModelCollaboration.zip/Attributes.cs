﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.Attributes
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace IfcModelCollaboration
{
  public class Attributes
  {
    private readonly List<string> header = new List<string>()
    {
      "//Tekla Structures;type;PDMS;type",
      "//PDMS.comment;string;:TEKLACOMMENT;string"
    };
    private readonly List<string> headerPDMS = new List<string>()
    {
      "//Discipline (Structural, Mechanical)",
      "//Level (Object, Branch, Pipe, Hvac, Equipment, Frmw, Stru, Zone, Site)",
      "//Discipline;Level;Attribute",
      "//Structural;Object;Name",
      "//Mechanical;Frmw;System"
    };

    internal bool GetAttributeMapping(
      string attributeMappingFile,
      out DataTable attributeMapping,
      out Errors errors)
    {
      errors = new Errors();
      bool flag = true;
      attributeMapping = this.AttributeMappingTable();
      if (!File.Exists(attributeMappingFile))
      {
        errors.ErrorCode = ErrorCode.FileDoesNotExist;
        errors.ErrorInfo = attributeMappingFile;
        return false;
      }
      try
      {
        using (StreamReader streamReader = new StreamReader(attributeMappingFile))
        {
          string str1;
          while ((str1 = streamReader.ReadLine()) != null)
          {
            str1.TrimStart();
            str1.TrimEnd();
            if (!str1.StartsWith("/"))
            {
              string[] strArray = str1.Split(';');
              if (strArray.Length == 4)
              {
                string str2 = strArray[0];
                try
                {
                  string str3 = strArray[1];
                  string str4 = strArray[2];
                  string str5 = strArray[3];
                  str2.TrimEnd();
                  str3.Trim().ToLower();
                  str4.Trim();
                  str5.TrimStart().ToLower();
                  AttributeType attributeType1 = AttributeType.String;
                  AttributeType attributeType2 = AttributeType.String;
                  if (!(str3 == "string"))
                  {
                    if (!(str3 == "double"))
                    {
                      if (str3 == "int")
                        attributeType1 = AttributeType.Integer;
                    }
                    else
                      attributeType1 = AttributeType.Double;
                  }
                  if (!(str5 == "string"))
                  {
                    if (!(str5 == "double"))
                    {
                      if (str5 == "int")
                        attributeType2 = AttributeType.Integer;
                    }
                    else
                      attributeType2 = AttributeType.Double;
                  }
                  if (attributeMapping.Rows.Find((object) str2) == null)
                    attributeMapping.Rows.Add((object) str2, (object) attributeType1, (object) str4, (object) attributeType2);
                }
                catch (Exception ex)
                {
                  errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
                  errors.ErrorInfo = str2;
                  flag = false;
                }
              }
            }
          }
        }
      }
      catch
      {
        errors.ErrorCode = ErrorCode.ReadingOfDataFailed;
        flag = false;
      }
      return flag;
    }

    internal bool GetAttributeMappingPDMS(
      string attributeMappingFile,
      out DataTable attributeMapping,
      out Errors errors)
    {
      errors = new Errors();
      List<string> stringList = new List<string>();
      bool flag1 = true;
      attributeMapping = this.AttributeMappingTablePDMS();
      if (!File.Exists(attributeMappingFile))
      {
        errors.ErrorCode = ErrorCode.FileDoesNotExist;
        errors.ErrorInfo = attributeMappingFile;
        return false;
      }
      try
      {
        using (StreamReader streamReader = new StreamReader(attributeMappingFile))
        {
          string str1;
          while ((str1 = streamReader.ReadLine()) != null)
          {
            str1.Trim();
            if (!str1.StartsWith("/"))
            {
              string[] strArray = str1.Split(';');
              if (strArray.Length >= 3 && strArray.Length <= 3)
              {
                string str2 = strArray[0].ToLower().Trim();
                Discipline discipline1 = Discipline.Structural;
                Discipline discipline2;
                if (discipline1.ToString().ToLower() == str2)
                {
                  discipline2 = Discipline.Structural;
                }
                else
                {
                  discipline1 = Discipline.Mechanical;
                  if (discipline1.ToString().ToLower() == str2)
                    discipline2 = Discipline.Mechanical;
                  else
                    continue;
                }
                string lower = strArray[1].ToLower();
                string str3 = strArray[2];
                bool flag2 = false;
                HierarchyLevel hierarchyLevel = HierarchyLevel.Object;
                IEnumerator enumerator = Enum.GetValues(typeof (HierarchyLevel)).GetEnumerator();
                while (enumerator.MoveNext())
                {
                  if (enumerator.Current != null)
                  {
                    HierarchyLevel current = (HierarchyLevel) enumerator.Current;
                    if (current.ToString().ToLower() == lower)
                    {
                      hierarchyLevel = current;
                      flag2 = true;
                    }
                  }
                }
                if (flag2)
                {
                  string str4 = str3.Trim();
                  string str5 = discipline2.ToString() + "-" + hierarchyLevel.ToString() + "-" + str4.ToLower();
                  try
                  {
                    if (!stringList.Contains(str5))
                    {
                      stringList.Add(str5);
                      attributeMapping.Rows.Add((object) discipline2, (object) hierarchyLevel, (object) str4);
                    }
                  }
                  catch (Exception ex)
                  {
                    errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
                    errors.ErrorInfo = str5;
                    flag1 = false;
                  }
                }
              }
            }
          }
        }
      }
      catch
      {
        errors.ErrorCode = ErrorCode.ReadingOfDataFailed;
        flag1 = false;
      }
      return flag1;
    }

    internal bool SaveAttributeMapping(
      string attributeMappingFile,
      DataTable attributeMapping,
      out Errors errors)
    {
      errors = new Errors();
      List<string> stringList = new List<string>();
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(attributeMappingFile))
        {
          foreach (string str in this.header)
            streamWriter.WriteLine(str);
          foreach (DataRow row in (InternalDataCollectionBase) attributeMapping.Rows)
          {
            try
            {
              string str1 = row["Tekla"].ToString().Trim();
              AttributeType attributeType1 = (AttributeType) row["TeklaType"];
              string str2 = row["Pdms"].ToString().Trim();
              AttributeType attributeType2 = (AttributeType) row["PdmsType"];
              if (!stringList.Contains(str1) && !string.IsNullOrEmpty(str1) && (!string.IsNullOrEmpty(attributeType1.ToString()) && !string.IsNullOrEmpty(str2)) && !string.IsNullOrEmpty(attributeType2.ToString()))
              {
                streamWriter.WriteLine(str1 + ";" + attributeType1.ToString() + ";" + str2 + ";" + attributeType2.ToString());
                stringList.Add(str1);
              }
              else
                errors.ErrorInfo = errors.ErrorInfo + "\n" + str1 + " has multiple definitions";
            }
            catch (Exception ex)
            {
              errors.ErrorInfo += "\nissue found";
            }
          }
        }
      }
      catch (Exception ex)
      {
        errors.ErrorCode = ErrorCode.FileCreationFailed;
        return false;
      }
      return true;
    }

    internal bool SaveAttributeMappingPDMS(
      string attributeMappingFile,
      DataTable attributeMapping,
      out Errors errors)
    {
      errors = new Errors();
      List<string> stringList = new List<string>();
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(attributeMappingFile))
        {
          foreach (string str in this.headerPDMS)
            streamWriter.WriteLine(str);
          foreach (DataRow row in (InternalDataCollectionBase) attributeMapping.Rows)
          {
            try
            {
              Discipline discipline = (Discipline) row["Discipline"];
              HierarchyLevel hierarchyLevel = (HierarchyLevel) row["HierarchyLevel"];
              string str1 = row["Attribute"].ToString().Trim();
              string str2 = discipline.ToString() + ";" + hierarchyLevel.ToString() + ";" + str1;
              if (!stringList.Contains(str2) && !string.IsNullOrEmpty(discipline.ToString()) && (!string.IsNullOrEmpty(hierarchyLevel.ToString()) && !string.IsNullOrEmpty(str1)))
              {
                streamWriter.WriteLine(str2);
                stringList.Add(str2);
              }
              else
                errors.ErrorInfo = errors.ErrorInfo + "\n" + str2 + " has multiple definitions";
            }
            catch (Exception ex)
            {
              errors.ErrorInfo += "\nissue found";
            }
          }
        }
      }
      catch (Exception ex)
      {
        errors.ErrorCode = ErrorCode.FileCreationFailed;
        return false;
      }
      return true;
    }

    private DataTable AttributeMappingTable()
    {
      DataTable dataTable = new DataTable(nameof (Attributes));
      DataColumn[] dataColumnArray = new DataColumn[1];
      DataColumn column = new DataColumn();
      column.ColumnName = "Tekla";
      column.DataType = typeof (string);
      dataTable.Columns.Add(column);
      dataColumnArray[0] = column;
      dataTable.Columns.Add("TeklaType", typeof (AttributeType));
      dataTable.Columns.Add("Pdms", typeof (string));
      dataTable.Columns.Add("PdmsType", typeof (AttributeType));
      dataTable.PrimaryKey = dataColumnArray;
      return dataTable;
    }

    private DataTable AttributeMappingTablePDMS()
    {
      return new DataTable("AttributesPDMS")
      {
        Columns = {
          {
            "Discipline",
            typeof (Discipline)
          },
          {
            "HierarchyLevel",
            typeof (HierarchyLevel)
          },
          {
            "Attribute",
            typeof (string)
          }
        }
      };
    }
  }
}
