﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.GuidHandler
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace IfcModelCollaboration
{
  internal class GuidHandler
  {
    internal bool GetGuids(
      ExportData data,
      out Dictionary<string, string> nativeGuidifcGuid,
      out List<string> nativeGuidList)
    {
      nativeGuidifcGuid = (Dictionary<string, string>) null;
      nativeGuidList = (List<string>) null;
      ImportData importData = new ImportData();
      if (!new FolderHierarchy().HandleFolderHierarchy(data.RootFolder, IfcModelCollaboration.IfcModelCollaboration.Action.Export, ref importData, ref data))
        return false;
      if (string.IsNullOrEmpty(data.ExportModelDataFolder))
      {
        data.Errors.ErrorCode = ErrorCode.DataMissing;
        data.Errors.ErrorInfo = "Path of ExportModelDataFolder";
        return false;
      }
      if (!File.Exists(data.ExportModelGuidsFile))
      {
        data.Errors.ErrorCode = ErrorCode.FileDoesNotExist;
        data.Errors.ErrorInfo = "ExportModelGuidsFile";
        return false;
      }
      DataTable dataTable;
      if (new XmlHandler().ReadXmlToDataTable(data.ExportModelGuidsFile, "Guids", out dataTable))
        return this.DataTableToDictionaryAndList(dataTable, out nativeGuidifcGuid, out nativeGuidList);
      data.Errors.ErrorCode = ErrorCode.ReadingOfDataFailed;
      data.Errors.ErrorInfo = "ExportModelGuidsFile";
      return false;
    }

    internal bool StoreGuids(ref ExportData data, Dictionary<string, string> nativeGuidifcGuid)
    {
      ImportData importData = new ImportData();
      if (!new FolderHierarchy().HandleFolderHierarchy(data.RootFolder, IfcModelCollaboration.IfcModelCollaboration.Action.Export, ref importData, ref data))
        return false;
      if (string.IsNullOrEmpty(data.ExportModelDataFolder))
      {
        data.Errors.ErrorCode = ErrorCode.DataMissing;
        data.Errors.ErrorInfo = "Path of ExportModelDataFolder";
        return false;
      }
      if (!Directory.Exists(data.ExportModelDataFolder))
      {
        try
        {
          Directory.CreateDirectory(data.ExportModelDataFolder);
        }
        catch
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = data.ExportModelDataFolder;
          return false;
        }
      }
      return this.WriteGuidsToXml(data.ExportModelGuidsFile, nativeGuidifcGuid, ref data);
    }

    private bool DataTableToDictionaryAndList(
      DataTable dataTable,
      out Dictionary<string, string> dic,
      out List<string> list)
    {
      dic = new Dictionary<string, string>();
      list = new List<string>();
      if (dataTable == null)
        return false;
      foreach (DataRow row in (InternalDataCollectionBase) dataTable.Rows)
      {
        try
        {
          dic.Add(row[0].ToString(), row[1].ToString());
          list.Add(row[0].ToString());
        }
        catch (Exception ex)
        {
        }
      }
      return true;
    }

    private bool WriteGuidsToXml(
      string exportModelGuidsFile,
      Dictionary<string, string> inputDict,
      ref ExportData data)
    {
      DataTable dataTable = new DataTable("Guids");
      dataTable.Columns.Add("TeklaGuid", typeof (string));
      dataTable.Columns.Add("IfcGuid", typeof (string));
      foreach (KeyValuePair<string, string> keyValuePair in inputDict)
        dataTable.Rows.Add((object) keyValuePair.Key, (object) keyValuePair.Value);
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(exportModelGuidsFile))
          dataTable.WriteXml((TextWriter) streamWriter);
      }
      catch (ConstraintException ex)
      {
        data.Errors.ErrorCode = ErrorCode.FileCreationFailed;
        data.Errors.ErrorInfo = exportModelGuidsFile;
        return false;
      }
      return true;
    }
  }
}
