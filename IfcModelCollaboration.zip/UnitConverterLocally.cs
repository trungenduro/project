﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.UnitConverterLocally
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Globalization;
using System.Text.RegularExpressions;

namespace IfcModelCollaboration
{
  internal class UnitConverterLocally
  {
    private bool ImperialUnits;
    private const double MM_TO_INCH_FACTOR = 0.0393700787401575;
    private const double INCH_TO_MM_FACTOR = 25.4;
    private const double FOOT_TO_INCH_FACTOR = 12.0;
    private const int FRACTION_DIVISOR = 128;

    internal UnitConverterLocally(bool ConvertToImperial)
    {
      this.ImperialUnits = ConvertToImperial;
    }

    internal string ConvertFromMmToCurrentUnits(double Value)
    {
      return !this.ImperialUnits ? Value.ToString("f2") : UnitConverterLocally.ConvertFromMmToFractionalInches(Value);
    }

    internal double ConvertFromCurrentUnitsToMm(string Value)
    {
      return !this.ImperialUnits ? Convert.ToDouble(Value) : 25.4 * this.ConvertTextFractionalInchesToDecimalInches(Value);
    }

    internal string FormatNumericTextIfNecessary(string Value)
    {
      return !this.ImperialUnits ? Convert.ToDouble(Value).ToString("f2") : this.FormatFractionalInchesText(Value);
    }

    internal bool TryConvertFromMmToCurrentUnits(double Value, out string ConvertResult)
    {
      string str = "";
      bool flag;
      try
      {
        str = this.ConvertFromMmToCurrentUnits(Value);
        flag = true;
      }
      catch
      {
        flag = false;
      }
      ConvertResult = str;
      return flag;
    }

    internal bool TryConvertFromCurrentUnitsToMm(string Value, out double ConvertedResult)
    {
      double num = 0.0;
      bool flag;
      try
      {
        num = this.ConvertFromCurrentUnitsToMm(Value);
        flag = true;
      }
      catch
      {
        flag = false;
      }
      ConvertedResult = num;
      return flag;
    }

    internal bool TryFormatNumericTextIfNecessary(string Value, out string FormatedResult)
    {
      string str = "";
      bool flag;
      try
      {
        str = this.FormatNumericTextIfNecessary(Value);
        flag = true;
      }
      catch
      {
        flag = false;
      }
      FormatedResult = str;
      return flag;
    }

    private static string ConvertFromMmToFractionalInches(double Value)
    {
      return UnitConverterLocally.GetFractionalInchesText(5.0 / (double) sbyte.MaxValue * Value);
    }

    private static string GetFractionalInchesText(double InchesValue)
    {
      string str = "";
      int num1 = 1;
      int num2 = 128;
      if (InchesValue < 0.0)
      {
        num1 = -1;
        InchesValue = Math.Abs(InchesValue);
      }
      int num3;
      int num4;
      int num5 = (int) (((double) (num4 = (int) (((double) (num3 = (int) (InchesValue / 12.0)) - (double) num3) * 12.0)) - Convert.ToDouble(num4)) * Convert.ToDouble(num2) + 0.5);
      if (num5 == num2)
      {
        num5 = 0;
        ++num4;
      }
      if (num4 == 12)
      {
        num4 = 0;
        ++num3;
      }
      for (; num2 % 2 == 0 && num5 % 2 == 0 && (num5 > 1 && num2 > 1); num2 /= 2)
        num5 /= 2;
      if (num1 == -1 && (num3 != 0 || num4 != 0 || num5 != 0))
        str = "-";
      if (num3 != 0)
      {
        str = str + num3.ToString() + "'";
        if (num4 != 0 || num5 != 0)
          str += "-";
      }
      if (num4 != 0 || num5 != 0)
        str = str + num4.ToString() + "\"";
      if (num5 != 0)
        str = str + " " + num5.ToString() + "/" + num2.ToString();
      if (str == "")
        str = "0";
      return str;
    }

    private string FormatFractionalInchesText(string Value)
    {
      Value.Split('\'');
      return UnitConverterLocally.GetFractionalInchesText(this.ConvertTextFractionalInchesToDecimalInches(Value));
    }

    private double ConvertTextFractionalInchesToDecimalInches(string Value)
    {
      double num = 0.0;
      string[] strArray = Value.Split('\'');
      if (strArray.Length.CompareTo(2) == 0)
        num = 12.0 * this.ConvertFractionToDecimal(strArray[0]) + this.ConvertFractionToDecimal(strArray[1]);
      else if (strArray.Length.CompareTo(1) == 0)
        num = this.ConvertFractionToDecimal(strArray[0]);
      return num;
    }

    private double ConvertFractionToDecimal(string Text)
    {
      double fraction = 0.0;
      if (this.CheckFraction(Text, out fraction))
        return fraction;
      string pattern1 = "(\\d+)[^0-9]*(\\d+)/(\\d+)";
      string pattern2 = "(\\d+)/(\\d+)";
      string pattern3 = "(\\d+)\\.(\\d+)";
      string pattern4 = "\\.?(\\d+)";
      if (Text.Equals(""))
        Text = "0";
      Match match1 = Regex.Match(Text, pattern1);
      Match match2 = Regex.Match(Text, pattern2);
      Match match3 = Regex.Match(Text, pattern3);
      Match match4 = Regex.Match(Text, pattern4);
      if (match1.Success)
      {
        GroupCollection groups = match1.Groups;
        return Convert.ToDouble(groups[1].Value) + Convert.ToDouble(groups[2].Value) / Convert.ToDouble(groups[3].Value);
      }
      if (match2.Success)
      {
        GroupCollection groups = match2.Groups;
        return Convert.ToDouble(groups[1].Value) / Convert.ToDouble(groups[2].Value);
      }
      if (match3.Success)
        return Convert.ToDouble(match3.Groups[0].Value);
      if (match4.Success)
        return Convert.ToDouble(match4.Groups[0].Value);
      throw new Exception("WrongFormatException");
    }

    private bool CheckFraction(string n, out double fraction)
    {
      fraction = 0.0;
      if (!n.Contains("/"))
        return false;
      double num = 0.0;
      try
      {
        string[] strArray = n.Split(' ');
        string str = strArray[0];
        if (strArray.Length == 2)
        {
          num = double.Parse(strArray[0].ToString((IFormatProvider) CultureInfo.InvariantCulture));
          str = strArray[1];
        }
        fraction = num + double.Parse(str.Remove(str.IndexOf("/")).ToString((IFormatProvider) CultureInfo.InvariantCulture)) / double.Parse(str.Remove(0, str.IndexOf("/") + 1).Replace("\"", string.Empty).ToString((IFormatProvider) CultureInfo.InvariantCulture));
        return true;
      }
      catch (Exception ex)
      {
        return false;
      }
    }
  }
}
