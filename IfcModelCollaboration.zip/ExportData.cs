﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ExportData
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public class ExportData
  {
    public DataInformation DataInformation { get; set; }

    internal string ExportModelsFolder { get; set; }

    internal string ExportModelDataFolder { get; set; }

    internal string ExportModelSettingsFile { get; set; }

    internal string ExportModelsSettingsFolder { get; set; }

    internal string ExportModelGuidsFile { get; set; }

    internal string ExportModelFolder { get; set; }

    internal string RootFolder { get; set; }

    internal string SoftwareFolder { get; set; }

    public Errors Errors { get; set; }
  }
}
