﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ImportToPdmsModel
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public class ImportToPdmsModel
  {
    public string Stru { get; set; }

    public string Frmw { get; set; }

    public string Name { get; set; }

    public bool Negatives { get; set; }

    public string DateTimeUtc { get; set; }

    public string NewDateTimeUtc { get; set; }

    public string Location { get; set; }
  }
}
