﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.Checking
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Globalization;

namespace IfcModelCollaboration
{
  public class Checking
  {
    internal void CheckSimilarityValue(double similarity, ref ImportData data)
    {
      data.Similarity = similarity;
      if (similarity < 0.7)
      {
        data.Similarity = 0.7;
        data.Errors.ErrorCode = ErrorCode.SimilarityAdjusted;
        data.Errors.ErrorInfo = similarity.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " -> " + data.Similarity.ToString();
      }
      else
      {
        if (similarity <= 1.0)
          return;
        data.Similarity = 1.0;
        data.Errors.ErrorCode = ErrorCode.SimilarityAdjusted;
        data.Errors.ErrorInfo = similarity.ToString((IFormatProvider) CultureInfo.InvariantCulture) + " -> " + data.Similarity.ToString();
      }
    }
  }
}
