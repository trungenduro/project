﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.DataInformationHandler
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;

namespace IfcModelCollaboration
{
  internal class DataInformationHandler
  {
    internal bool ReadDataInformation(string dataInformationFolder, ref ImportData data)
    {
      bool flag = true;
      string str1 = string.Empty;
      data.DataInformation.IsImperial = false;
      string path = dataInformationFolder + "\\DataInformation.xml";
      if (!File.Exists(path))
        return false;
      using (StreamReader streamReader = new StreamReader(path, Encoding.UTF8))
      {
        using (XmlTextReader xmlTextReader = new XmlTextReader((TextReader) streamReader))
        {
          string str2 = string.Empty;
          while (xmlTextReader.Read())
          {
            switch (xmlTextReader.NodeType)
            {
              case XmlNodeType.Element:
                str2 = xmlTextReader.Name;
                continue;
              case XmlNodeType.Text:
                string s = xmlTextReader.Value;
                if (str2.Equals("ExportSoftware") && s != data.DataInformation.ExportSoftware.ToString())
                {
                  data.Errors.ErrorInfo = s + " != " + (object) data.DataInformation.ExportSoftware;
                  data.Errors.ErrorCode = ErrorCode.PacketIsNotValid;
                }
                if (str2.Equals("ImportSoftware") && s != data.DataInformation.ImportSoftware.ToString())
                {
                  data.Errors.ErrorInfo = s + " != " + (object) data.DataInformation.ImportSoftware;
                  data.Errors.ErrorCode = ErrorCode.PacketIsNotValid;
                }
                if (str2.Equals("Version"))
                {
                  data.DataInformation.SoftwareVersion = s;
                  continue;
                }
                if (str2.Equals("ApplicationVersion"))
                {
                  int result;
                  int.TryParse(s, out result);
                  data.DataInformation.ApplicationVersion = result;
                  continue;
                }
                if (str2.Equals("LinkVersion"))
                {
                  int result;
                  int.TryParse(s, out result);
                  data.DataInformation.LinkVersion = result;
                  continue;
                }
                if (str2.Equals("Name"))
                {
                  data.DataInformation.Name = s;
                  continue;
                }
                if (str2.Equals("NameFull"))
                {
                  data.DataInformation.NameFull = s;
                  continue;
                }
                if (str2.Equals("DateTimeUtc"))
                {
                  data.DataInformation.DateTimeUtc = s;
                  continue;
                }
                if (str2.Equals("Guid"))
                {
                  str1 = s;
                  continue;
                }
                if (str2.Equals("Imperial"))
                {
                  if (s.ToUpper() == "TRUE")
                  {
                    data.DataInformation.IsImperial = true;
                    continue;
                  }
                  continue;
                }
                if (str2.Equals("Hierarchy") && s.ToUpper() == "TRUE")
                {
                  data.DataInformation.Hierarchy = true;
                  continue;
                }
                continue;
              default:
                continue;
            }
          }
        }
        Tools tools = new Tools();
        if (str1 != tools.MakePacketUnique(data.DataInformation.Name, data.DataInformation.DateTimeUtc))
        {
          data.Errors.ErrorCode = ErrorCode.PacketIsNotValid;
          data.Errors.ErrorInfo = "Packet changed manually";
          flag = false;
        }
      }
      FileInfo fileInfo = new FileInfo(data.NewImportVersionFile);
      string str3 = fileInfo.Name.Replace(fileInfo.Extension, string.Empty);
      if (data.DataInformation.NameFull != str3)
      {
        data.Errors.ErrorCode = ErrorCode.PacketIsNotValid;
        data.Errors.ErrorInfo = "Packet changed manually";
        flag = false;
      }
      return flag;
    }

    internal bool WriteDataInformation(
      string folder,
      ref DataInformation dataInformation,
      ref Errors errors)
    {
      if (!Directory.Exists(folder))
      {
        try
        {
          Directory.CreateDirectory(folder);
        }
        catch (Exception ex)
        {
          errors.ErrorCode = ErrorCode.FolderCreationFailed;
          errors.ErrorInfo = folder;
          return false;
        }
      }
      string str1 = dataInformation.ExportSoftware.ToString();
      string str2 = dataInformation.ImportSoftware.ToString();
      string softwareVersion = dataInformation.SoftwareVersion;
      int applicationVersion = dataInformation.ApplicationVersion;
      int linkVersion = dataInformation.LinkVersion;
      bool hierarchy = dataInformation.Hierarchy;
      if (string.IsNullOrEmpty(str1) || linkVersion == 0)
      {
        errors.ErrorCode = ErrorCode.ParameterMissing;
        errors.ErrorInfo = "DataInformation";
        return false;
      }
      string str3 = new Tools().MakePacketUnique(dataInformation.Name, dataInformation.DateTimeUtc);
      bool isImperial = dataInformation.IsImperial;
      DataTable dataTable = new DataTable("DataInformation");
      dataTable.Columns.Add("ExportSoftware", typeof (string));
      dataTable.Columns.Add("ImportSoftware", typeof (string));
      dataTable.Columns.Add("Version", typeof (string));
      dataTable.Columns.Add("ApplicationVersion", typeof (int));
      dataTable.Columns.Add("LinkVersion", typeof (int));
      dataTable.Columns.Add("Name", typeof (string));
      dataTable.Columns.Add("NameFull", typeof (string));
      dataTable.Columns.Add("DateTimeUtc", typeof (string));
      dataTable.Columns.Add("Guid", typeof (string));
      dataTable.Columns.Add("Imperial", typeof (string));
      if (str2 == SoftwareOptions.PDMS.ToString())
      {
        dataTable.Columns.Add("Hierarchy", typeof (bool));
        dataTable.Rows.Add((object) str1, (object) str2, (object) softwareVersion, (object) applicationVersion, (object) linkVersion, (object) dataInformation.Name, (object) dataInformation.NameFull, (object) dataInformation.DateTimeUtc, (object) str3, (object) isImperial, (object) hierarchy);
      }
      else
        dataTable.Rows.Add((object) str1, (object) str2, (object) softwareVersion, (object) applicationVersion, (object) linkVersion, (object) dataInformation.Name, (object) dataInformation.NameFull, (object) dataInformation.DateTimeUtc, (object) str3, (object) isImperial);
      return this.WriteXml(folder + "\\DataInformation.xml", dataTable, ref errors);
    }

    private bool WriteXml(string file, DataTable dataTable, ref Errors errors)
    {
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(file))
          dataTable.WriteXml((TextWriter) streamWriter);
      }
      catch (ConstraintException ex)
      {
        errors.ErrorCode = ErrorCode.FileCreationFailed;
        errors.ErrorInfo = file;
        return false;
      }
      return true;
    }
  }
}
