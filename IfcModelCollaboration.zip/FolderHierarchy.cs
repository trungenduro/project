﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.FolderHierarchy
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.IO;

namespace IfcModelCollaboration
{
  internal class FolderHierarchy
  {
    internal bool HandleFolderHierarchy(
      string folder,
      IfcModelCollaboration.IfcModelCollaboration.Action action,
      ref ImportData importData,
      ref ExportData exportData)
    {
      if (!this.CreateDirectory(folder))
      {
        importData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
        importData.Errors.ErrorInfo = folder;
        return false;
      }
      folder += "\\Links";
      if (!this.CreateDirectory(folder))
      {
        importData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
        importData.Errors.ErrorInfo = folder;
        return false;
      }
      switch (action)
      {
        case IfcModelCollaboration.IfcModelCollaboration.Action.Export:
          exportData.SoftwareFolder = folder + "\\" + (object) exportData.DataInformation.ImportSoftware;
          if (!this.CreateDirectory(exportData.SoftwareFolder))
          {
            exportData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            exportData.Errors.ErrorInfo = exportData.SoftwareFolder;
            return false;
          }
          exportData.ExportModelsFolder = exportData.SoftwareFolder + "\\" + (object) action;
          if (!this.CreateDirectory(exportData.ExportModelsFolder))
          {
            exportData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            exportData.Errors.ErrorInfo = exportData.ExportModelsFolder;
            return false;
          }
          exportData.ExportModelsSettingsFolder = exportData.ExportModelsFolder + "\\Settings";
          if (!this.CreateDirectory(exportData.ExportModelsSettingsFolder))
          {
            exportData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            exportData.Errors.ErrorInfo = "SettingsFolder";
            return false;
          }
          break;
        case IfcModelCollaboration.IfcModelCollaboration.Action.Import:
          importData.SoftwareFolder = folder + "\\" + (object) importData.DataInformation.ExportSoftware;
          if (!this.CreateDirectory(importData.SoftwareFolder))
          {
            importData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            importData.Errors.ErrorInfo = importData.SoftwareFolder;
            return false;
          }
          importData.ImportModelsFolder = importData.SoftwareFolder + "\\" + (object) action;
          if (!this.CreateDirectory(importData.ImportModelsFolder))
          {
            importData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            importData.Errors.ErrorInfo = importData.ImportModelsFolder;
            return false;
          }
          importData.ImportModelsSettingsFolder = importData.ImportModelsFolder + "\\Settings";
          if (!this.CreateDirectory(importData.ImportModelsSettingsFolder))
          {
            importData.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            importData.Errors.ErrorInfo = "SettingsFolder";
            return false;
          }
          break;
      }
      return true;
    }

    internal bool RemoveFolderHierarchy(
      string rootfolder,
      IfcModelCollaboration.IfcModelCollaboration.Action action,
      SoftwareOptions softwareOption,
      string selectedModel)
    {
      string path = rootfolder + "\\Links\\" + (object) softwareOption + "\\" + (object) action + "\\" + selectedModel;
      if (Directory.Exists(path))
      {
        try
        {
          Directory.Delete(path, true);
        }
        catch (Exception ex)
        {
          return false;
        }
      }
      return true;
    }

    private bool CreateDirectory(string folder)
    {
      if (!Directory.Exists(folder))
      {
        try
        {
          Directory.CreateDirectory(folder);
        }
        catch (Exception ex)
        {
          return false;
        }
      }
      return true;
    }
  }
}
