﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.RevitInterface
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System.IO;

namespace IfcModelCollaboration
{
  public class RevitInterface
  {
    public DataInformation GetDataInformation(
      string packetFile,
      string dataInformationFile,
      int linkVersion,
      out Errors errors)
    {
      object obj = new object();
      errors = new Errors();
      if (!File.Exists(dataInformationFile))
      {
        errors.ErrorCode = ErrorCode.FileDoesNotExist;
        errors.ErrorInfo = dataInformationFile;
        return (DataInformation) null;
      }
      FileInfo fileInfo = new FileInfo(dataInformationFile);
      ImportData data = new ImportData()
      {
        DataInformation = new DataInformation(),
        Errors = new Errors()
      };
      data.DataInformation.ExportSoftware = SoftwareOptions.TeklaStructures;
      data.DataInformation.ImportSoftware = SoftwareOptions.Revit;
      data.DataInformation.LinkVersion = linkVersion;
      data.NewImportVersionFile = packetFile;
      DataInformationHandler informationHandler = new DataInformationHandler();
      if (fileInfo.Directory == null)
      {
        errors.ErrorCode = ErrorCode.FileDoesNotExist;
        return (DataInformation) null;
      }
      if (!informationHandler.ReadDataInformation(fileInfo.Directory.FullName, ref data))
      {
        if (data.Errors.ErrorCode != ErrorCode.PacketIsNotValid)
        {
          errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
          return (DataInformation) null;
        }
        errors = data.Errors;
        return (DataInformation) null;
      }
      errors = data.Errors;
      if (errors.ErrorCode != ErrorCode.None || !string.IsNullOrEmpty(errors.ErrorInfo))
        return (DataInformation) null;
      return data.DataInformation;
    }
  }
}
