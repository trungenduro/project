﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("IfcModelCollaboration")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Trimble Solutions Oy")]
[assembly: AssemblyProduct("IfcModelCollaboration")]
[assembly: AssemblyCopyright("Copyright © Trimble Solutions Oy")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("7facb5e7-db3c-44f8-ab59-53ffbdfbb41b")]
[assembly: AssemblyFileVersion("2099.1.0.0")]
[assembly: AssemblyVersion("2099.1.0.0")]
