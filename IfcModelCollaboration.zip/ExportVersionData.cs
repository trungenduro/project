﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ExportVersionData
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  public class ExportVersionData
  {
    public string Guid { get; set; }

    public string Name { get; set; }

    public string NameFull { get; set; }

    public string DateTimeUtc { get; set; }

    public ExportContentOptions Content { get; set; }

    public string Filter { get; set; }

    public string Folder { get; set; }

    public string FolderAbsolute { get; set; }

    public string ToVersion { get; set; }

    public bool Stored { get; set; }
  }
}
