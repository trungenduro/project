﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ImportData
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System.Collections.Generic;

namespace IfcModelCollaboration
{
  public class ImportData
  {
    public DataInformation DataInformation;

    public string RootFolder { get; set; }

    public string SoftwareFolder { get; internal set; }

    public string ImportModelsFolder { get; internal set; }

    public string ImportModelFolder { get; internal set; }

    public string ImportModelsSettingsFolder { get; internal set; }

    public string NewImportVersionFolder { get; internal set; }

    public string NewImportVersionConversionFolder { get; internal set; }

    public string NewImportVersionDataFolder { get; internal set; }

    public List<string> NewImportVersionProfiles { get; internal set; }

    public Dictionary<string, string> NewImportVersionMaterials { get; internal set; }

    public string PreviousImportVersionFolder { get; internal set; }

    public string NewImportVersionFile { get; internal set; }

    public string PreviousImportVersionDataFolder { get; internal set; }

    public string PreviousImportVersionFile { get; internal set; }

    public double Similarity { get; internal set; }

    public Errors Errors { get; set; }
  }
}
