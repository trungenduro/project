﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ClassSerializer
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.IO;
using System.Xml.Serialization;

namespace IfcModelCollaboration
{
  internal class ClassSerializer
  {
    internal bool ToXml(object obj, string file, bool backUp)
    {
      if (backUp && !this.HandleBackUpFile(file))
        return false;
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(file))
        {
          new XmlSerializer(obj.GetType()).Serialize((TextWriter) streamWriter, obj);
          streamWriter.Close();
        }
      }
      catch (Exception ex)
      {
        return false;
      }
      return true;
    }

    private bool HandleBackUpFile(string file)
    {
      try
      {
        if (File.Exists(file))
        {
          if (!File.Exists(file + ".bak"))
          {
            File.Copy(file, file + ".bak", true);
            File.SetLastWriteTime(file + ".bak", DateTime.Now);
          }
        }
      }
      catch
      {
        return false;
      }
      return true;
    }

    private bool HandleBackUp0File(string file)
    {
      try
      {
        if (File.Exists(file))
          File.Copy(file, file + ".bak0", true);
      }
      catch
      {
        return false;
      }
      return true;
    }

    internal bool FromXml(ref object obj, string file)
    {
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(obj.GetType());
        using (StreamReader streamReader = new StreamReader(file))
        {
          obj = xmlSerializer.Deserialize((TextReader) streamReader);
          streamReader.Close();
          return true;
        }
      }
      catch (Exception ex)
      {
        if (!this.TryConvertXml(ref obj, file))
          return false;
      }
      return true;
    }

    private bool TryConvertXml(ref object obj, string file)
    {
      string str1 = obj.GetType().ToString().Remove(0, obj.GetType().ToString().IndexOf(".", StringComparison.Ordinal) + 1);
      string str2 = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<" + str1 + " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">";
      string str3 = string.Empty;
      using (StreamReader streamReader = new StreamReader(file))
      {
        string str4;
        while ((str4 = streamReader.ReadLine()) != null)
        {
          if (!str4.Contains("DocumentElement>") && !str4.Contains("Versions>"))
            str3 = str3 + "\r\n" + str4;
        }
        streamReader.Close();
      }
      if (string.IsNullOrEmpty(str3))
        return false;
      string s = str2 + str3 + "\r\n</" + str1 + ">";
      try
      {
        XmlSerializer xmlSerializer = new XmlSerializer(obj.GetType());
        using (StringReader stringReader = new StringReader(s))
        {
          obj = xmlSerializer.Deserialize((TextReader) stringReader);
          stringReader.Close();
          return true;
        }
      }
      catch (Exception ex)
      {
        return false;
      }
    }
  }
}
