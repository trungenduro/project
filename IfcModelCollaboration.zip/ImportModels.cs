﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ImportModels
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using Ionic.Zip;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace IfcModelCollaboration
{
  internal class ImportModels
  {
    private string modelName = string.Empty;
    private string name = string.Empty;
    private const string ProfilesDotXml = "Profiles.xml";

    internal bool HandleModel(
      string file,
      ref ImportData data,
      out string nameReturn,
      out string dateTimeUtc,
      out string folder)
    {
      nameReturn = string.Empty;
      dateTimeUtc = string.Empty;
      folder = string.Empty;
      FileInfo fileInfo1 = new FileInfo(file);
      if (fileInfo1.Directory != null)
        folder = fileInfo1.Directory.FullName;
      this.modelName = fileInfo1.Name.Replace(fileInfo1.Extension, string.Empty);
      string[] strArray = this.modelName.Split('#');
      if (strArray.Length != 2)
      {
        data.Errors.ErrorCode = ErrorCode.InvalidFileName;
        data.Errors.ErrorInfo = this.modelName + "." + fileInfo1.Extension + " is not *#*.ifcZIP or .tcZip";
        return false;
      }
      this.name = strArray[0];
      nameReturn = this.name;
      dateTimeUtc = strArray[1];
      data.ImportModelFolder = data.ImportModelsFolder + "\\" + this.name;
      if (!Directory.Exists(data.ImportModelFolder))
      {
        try
        {
          Directory.CreateDirectory(data.ImportModelFolder);
        }
        catch (Exception ex)
        {
          return false;
        }
      }
      FileInfo fileInfo2 = new FileInfo(file);
      string str = Path.GetTempPath() + "\\" + DateTime.UtcNow.Ticks.ToString() + "\\";
      if (fileInfo2.Extension.ToUpper() == ".ifcZIP".ToUpper() || fileInfo2.Extension.ToUpper() == ".tcZip".ToUpper())
      {
        try
        {
          Directory.CreateDirectory(str);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = str;
          return false;
        }
        if (!this.Uncompress(file, str, ref data))
        {
          data.Errors.ErrorCode = ErrorCode.UncompressingFailed;
          data.Errors.ErrorInfo = str;
          return false;
        }
      }
      data.NewImportVersionFile = file;
      DataInformationHandler informationHandler = new DataInformationHandler();
      if (Directory.Exists(str))
      {
        if (!informationHandler.ReadDataInformation(str, ref data))
        {
          if (data.Errors.ErrorCode != ErrorCode.PacketIsNotValid)
            data.Errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
          data.NewImportVersionFile = string.Empty;
          return false;
        }
        data.NewImportVersionFile = string.Empty;
        this.HandleLatestVersionFolder(ref data);
        if (this.HandlePacketContent(str, data.NewImportVersionFolder, ref data))
          return true;
        data.Errors.ErrorCode = ErrorCode.FileCopyFailed;
        data.Errors.ErrorInfo = "Files to " + data.NewImportVersionFolder;
        return false;
      }
      data.Errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
      data.Errors.ErrorInfo = "Temp folder missing";
      data.NewImportVersionFile = string.Empty;
      return false;
    }

    internal bool HandleModelUpdate(string file, ref ImportData data)
    {
      FileInfo fileInfo = new FileInfo(file);
      this.modelName = fileInfo.Name.Replace(fileInfo.Extension, string.Empty);
      string[] strArray = this.modelName.Split('#');
      if (strArray.Length != 2)
      {
        data.Errors.ErrorCode = ErrorCode.InvalidFileName;
        data.Errors.ErrorInfo = this.modelName + "." + fileInfo.Extension + " is not *#*.ifcZIP or .tcZip";
        return false;
      }
      this.name = strArray[0];
      data.ImportModelFolder = data.ImportModelsFolder + "\\" + this.name;
      if (!Directory.Exists(data.ImportModelFolder))
      {
        try
        {
          Directory.CreateDirectory(data.ImportModelFolder);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = data.ImportModelFolder;
          return false;
        }
      }
      List<string> list = this.CheckVersions(ref data);
      string tempFolder = string.Empty;
      if (!this.HandleUncompressing(file, ref data, out tempFolder))
      {
        data.Errors.ErrorCode = ErrorCode.UncompressingFailed;
        return false;
      }
      data.NewImportVersionFile = file;
      DataInformationHandler informationHandler = new DataInformationHandler();
      string str = tempFolder + "\\DataInformation.xml";
      if (File.Exists(str) && !informationHandler.ReadDataInformation(str, ref data))
      {
        if (data.Errors.ErrorCode != ErrorCode.PacketIsNotValid)
          data.Errors.ErrorCode = ErrorCode.DataInformationReadingFailed;
        data.NewImportVersionFile = string.Empty;
        return false;
      }
      data.NewImportVersionFile = string.Empty;
      if (string.IsNullOrEmpty(data.DataInformation.DateTimeUtc))
      {
        DateTime universalTime = DateTime.Now.ToUniversalTime();
        data.DataInformation.DateTimeUtc = universalTime.Year.ToString((IFormatProvider) CultureInfo.InvariantCulture) + string.Format("{0:00}", (object) universalTime.Month) + string.Format("{0:00}", (object) universalTime.Day) + "_" + string.Format("{0:00}", (object) universalTime.Hour) + string.Format("{0:00}", (object) universalTime.Minute) + string.Format("{0:00}", (object) universalTime.Second);
      }
      else
      {
        long num1;
        try
        {
          num1 = long.Parse(data.DataInformation.DateTimeUtc.Replace("-", string.Empty));
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.VersionReadingError;
          data.Errors.ErrorInfo = data.DataInformation.DateTimeUtc;
          return false;
        }
        if (list.Count > 0)
        {
          long num2;
          try
          {
            num2 = long.Parse(list[0].Replace("-", string.Empty));
          }
          catch (Exception ex)
          {
            data.Errors.ErrorCode = ErrorCode.VersionReadingError;
            data.Errors.ErrorInfo = data.DataInformation.DateTimeUtc;
            return false;
          }
          if (num1 < num2)
          {
            data.Errors.ErrorCode = ErrorCode.OldVersion;
            data.Errors.ErrorInfo = data.DataInformation.DateTimeUtc + " < " + list[0];
            return false;
          }
          bool sameVersion = num1 == num2;
          if (list.Count > 1 && !this.HandleVersions(sameVersion, list, ref data))
            return false;
        }
      }
      this.HandleLatestVersionFolder(ref data);
      if (!string.IsNullOrEmpty(data.NewImportVersionFolder) && !this.CopyModel(file, data.ImportModelFolder, ref data))
      {
        data.Errors.ErrorCode = ErrorCode.FileCopyFailed;
        data.Errors.ErrorInfo = "Files to " + data.ImportModelFolder;
        return false;
      }
      if (!this.HandlePacketContent(tempFolder, data.NewImportVersionFolder, ref data))
      {
        data.Errors.ErrorCode = ErrorCode.FileCopyFailed;
        data.Errors.ErrorInfo = "Files to " + data.NewImportVersionFolder;
        return false;
      }
      this.CreateProfileList(ref data);
      return true;
    }

    internal bool HandleUncompressing(string file, ref ImportData data, out string tempFolder)
    {
      tempFolder = string.Empty;
      FileInfo fileInfo = new FileInfo(file);
      if (!new IfcModelCollaboration.IfcModelCollaboration().CreateTempExportFolder(out tempFolder))
      {
        data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
        data.Errors.ErrorInfo = tempFolder;
        return false;
      }
      if (this.Uncompress(file, tempFolder, ref data))
        return true;
      data.Errors.ErrorCode = ErrorCode.UncompressingFailed;
      data.Errors.ErrorInfo = tempFolder;
      return false;
    }

    internal bool CreateProfileList(ref ImportData data)
    {
      string str = data.NewImportVersionDataFolder + "\\Profiles.xml";
      if (!File.Exists(str))
      {
        data.Errors.ErrorCode = ErrorCode.ProfilesFileMissing;
        return false;
      }
      DataSet dataSet;
      if (!new XmlHandler().ReadXmlToDataSet(str, out dataSet))
      {
        data.Errors.ErrorCode = ErrorCode.ReadingOfFileFailed;
        data.Errors.ErrorInfo = "Profiles.xml";
      }
      else
        data.NewImportVersionProfiles = this.ListProfiles(dataSet, ref data);
      return true;
    }

    internal bool HandlePacketContent(
      string tempFolder,
      string currentImportVersionFolder,
      ref ImportData data)
    {
      bool flag = true;
      string str = currentImportVersionFolder + "\\Data";
      DirectoryInfo directoryInfo = new DirectoryInfo(tempFolder);
      if (true)
      {
        try
        {
          Directory.CreateDirectory(str);
          data.NewImportVersionDataFolder = str;
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = str;
          flag = false;
        }
        try
        {
          this.CopyAll(tempFolder, str);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FileCopyFailed;
          data.Errors.ErrorInfo = tempFolder + " -> " + str;
        }
        string path = str + "\\" + data.DataInformation.Name + "#" + data.DataInformation.DateTimeUtc + ".ifc";
        if (File.Exists(path))
          data.NewImportVersionFile = path;
      }
      try
      {
        Directory.Delete(tempFolder, true);
      }
      catch (Exception ex)
      {
      }
      return flag;
    }

    internal bool WriteSettingsFile(string settingsFile, DataTable dataTable, ref ImportData data)
    {
      try
      {
        using (StreamWriter streamWriter = new StreamWriter(settingsFile))
          dataTable.WriteXml((TextWriter) streamWriter);
      }
      catch (ConstraintException ex)
      {
        data.Errors.ErrorCode = ErrorCode.FileCreationFailed;
        data.Errors.ErrorInfo = settingsFile;
        return false;
      }
      return true;
    }

    internal bool FindUpdates(string folder, string name, string datetime, out string newDateTime)
    {
      newDateTime = string.Empty;
      List<long> longList = new List<long>();
      if (!Directory.Exists(folder))
        return false;
      foreach (FileInfo file in new DirectoryInfo(folder).GetFiles())
      {
        if ((file.Extension.ToUpper() == ".tcZip".ToUpper() || file.Extension.ToUpper() == ".ifcZIP".ToUpper()) && file.Name.StartsWith(name + "#"))
        {
          string str = file.Name.Replace(name + "#", string.Empty).Replace(file.Extension, string.Empty);
          if (str.Split('-').Length == 2)
          {
            try
            {
              long num = long.Parse(str.Replace("-", string.Empty));
              longList.Add(num);
            }
            catch (Exception ex)
            {
            }
          }
        }
      }
      longList.Sort();
      longList.Reverse();
      long num1 = 0;
      try
      {
        num1 = long.Parse(datetime.Replace("-", string.Empty));
      }
      catch (Exception ex)
      {
      }
      if (longList.Count > 0 && num1 < longList[0])
        newDateTime = longList[0].ToString((IFormatProvider) CultureInfo.InvariantCulture).Insert(8, "-");
      return true;
    }

    internal bool GetImportModelsData(object dataType, ref ImportData data, out List<object> list)
    {
      list = (List<object>) null;
      return this.ReadImportVersions(dataType, ref data, out list);
    }

    internal bool GetImportModelData(
      string settingsFile,
      object dataType,
      ref ImportData data,
      out object model)
    {
      model = (object) null;
      return this.ReadImportVersion(settingsFile, dataType, ref data, out model);
    }

    private List<string> ListProfiles(DataSet dataSet, ref ImportData data)
    {
      List<string> stringList = new List<string>();
      if (dataSet == null)
        return stringList;
      DataTable table = dataSet.Tables["Profiles"];
      if (table != null)
      {
        foreach (DataRow row in (InternalDataCollectionBase) table.Rows)
        {
          try
          {
            string str = row["ProfileName"].ToString();
            if (!stringList.Contains(str))
              stringList.Add(str);
          }
          catch (Exception ex)
          {
            data.Errors.ErrorCode = ErrorCode.ReadingOfDataFailed;
            data.Errors.ErrorInfo = "Profiles information";
          }
        }
      }
      return stringList;
    }

    private List<string> CheckVersions(ref ImportData data)
    {
      List<string> stringList = new List<string>();
      foreach (FileInfo file in new DirectoryInfo(data.ImportModelFolder).GetFiles())
      {
        if (file.Name.StartsWith(data.DataInformation.Name + "#") && file.Extension == ".ifcZIP")
        {
          string str = file.Name.Replace(data.DataInformation.Name + "#", string.Empty).Replace(file.Extension, string.Empty);
          string[] strArray = str.Split('-');
          if (strArray.Length == 2)
          {
            try
            {
              int.Parse(strArray[0]);
              int.Parse(strArray[1]);
              stringList.Add(str);
            }
            catch (Exception ex)
            {
            }
          }
        }
      }
      stringList.Sort();
      stringList.Reverse();
      return stringList;
    }

    private bool HandleVersions(bool sameVersion, List<string> list, ref ImportData data)
    {
      if (list.Count > 0)
      {
        for (int index = 0; index < list.Count; ++index)
        {
          if (!sameVersion || index != 0)
          {
            string str1 = list[index];
            string str2 = data.ImportModelFolder + "\\" + str1;
            string path = data.ImportModelFolder + "\\" + this.modelName + ".ifcZIP";
            if (File.Exists(path))
            {
              data.PreviousImportVersionFolder = str2;
              data.PreviousImportVersionFile = path;
              break;
            }
          }
        }
      }
      return true;
    }

    private void HandleLatestVersionFolder(ref ImportData data)
    {
      string path = data.ImportModelFolder + "\\" + data.DataInformation.DateTimeUtc;
      if (!Directory.Exists(path))
      {
        try
        {
          Directory.CreateDirectory(path);
          data.NewImportVersionFolder = path;
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = path;
        }
      }
      else
        data.NewImportVersionFolder = path;
    }

    private bool CopyModel(string file, string currentFolder, ref ImportData data)
    {
      FileInfo fileInfo = new FileInfo(file);
      data.NewImportVersionFile = currentFolder + "\\" + fileInfo.Name;
      if (!File.Exists(data.NewImportVersionFile))
      {
        try
        {
          File.Copy(file, data.NewImportVersionFile);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FileCopyFailed;
          data.Errors.ErrorInfo = file + ":" + data.NewImportVersionFile;
          return false;
        }
      }
      return true;
    }

    private bool Uncompress(string zipFilePath, string currentFolder, ref ImportData data)
    {
      try
      {
        using (FileStream fileStream = new FileStream(zipFilePath, FileMode.Open, FileAccess.Read))
        {
          bool extractFinished = false;
          using (ZipFile zipFile = ZipFile.Read((Stream) fileStream))
          {
            zipFile.AlternateEncodingUsage = ZipOption.AsNecessary;
            zipFile.AlternateEncoding = Encoding.UTF8;
            zipFile.ExtractProgress += (EventHandler<ExtractProgressEventArgs>) ((sender, e) =>
            {
              if (e.EventType != ZipProgressEventType.Extracting_AfterExtractAll)
                return;
              extractFinished = true;
            });
            zipFile.ExtractAll(currentFolder, ExtractExistingFileAction.OverwriteSilently);
            while (!extractFinished)
              Thread.Sleep(300);
            return true;
          }
        }
      }
      catch
      {
        data.Errors.ErrorCode = ErrorCode.UncompressingFailed;
        data.Errors.ErrorInfo = zipFilePath;
        return false;
      }
    }

    private void CopyAll(string sourceDirName, string destDirName)
    {
      bool flag = true;
      DirectoryInfo directoryInfo1 = new DirectoryInfo(sourceDirName);
      DirectoryInfo[] directories = directoryInfo1.GetDirectories();
      if (!directoryInfo1.Exists)
        throw new DirectoryNotFoundException("Source directory does not exist or could not be found: " + sourceDirName);
      if (!Directory.Exists(destDirName))
        Directory.CreateDirectory(destDirName);
      foreach (FileInfo file in directoryInfo1.GetFiles())
      {
        string str = Path.Combine(destDirName, file.Name);
        if (!File.Exists(str))
          file.CopyTo(str, false);
      }
      if (!flag)
        return;
      foreach (DirectoryInfo directoryInfo2 in directories)
      {
        string str = Path.Combine(destDirName, directoryInfo2.Name);
        if (!Directory.Exists(str))
          this.CopyAll(directoryInfo2.FullName, str);
      }
    }

    private bool CheckGeneralSettings(ref ExportData data, ref DataSet dataSet)
    {
      DataTable dataTable = new DataTable();
      return dataSet.Tables["Settings"] != null;
    }

    private bool ReadImportVersion(
      string settingsFile,
      object dataType,
      ref ImportData data,
      out object model)
    {
      ClassSerializer classSerializer = new ClassSerializer();
      model = new object();
      if (File.Exists(settingsFile) && classSerializer.FromXml(ref dataType, settingsFile))
        model = dataType;
      return true;
    }

    private bool ReadImportVersions(object dataType, ref ImportData data, out List<object> list)
    {
      ClassSerializer classSerializer = new ClassSerializer();
      list = new List<object>();
      foreach (FileSystemInfo directory in new DirectoryInfo(data.ImportModelsFolder).GetDirectories())
      {
        string name = directory.Name;
        if (!(name == "Settings"))
        {
          string path = data.ImportModelsFolder + "\\" + name + "\\Data";
          string str = path + "\\Settings.xml";
          try
          {
            if (!Directory.Exists(path))
              Directory.CreateDirectory(path);
          }
          catch (Exception ex)
          {
            data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            data.Errors.ErrorInfo = path;
            return false;
          }
          if (File.Exists(str) && classSerializer.FromXml(ref dataType, str) && !list.Contains(dataType))
            list.Add(dataType);
        }
      }
      return true;
    }
  }
}
