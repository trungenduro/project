﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.ExportModels
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System;
using System.Collections.Generic;
using System.IO;

namespace IfcModelCollaboration
{
  internal class ExportModels
  {
    internal bool GetExportModelsData(object dataType, ref ExportData data, out List<object> list)
    {
      list = (List<object>) null;
      return this.ReadVersions(dataType, ref data, out list);
    }

    internal void GetModelSpecificData(string name, ref ExportData data)
    {
      if (string.IsNullOrEmpty(data.ExportModelFolder))
        data.ExportModelFolder = data.ExportModelsFolder + "\\" + name;
      data.ExportModelDataFolder = data.ExportModelFolder + "\\Data";
      data.ExportModelSettingsFile = data.ExportModelDataFolder + "\\Settings.xml";
      data.ExportModelGuidsFile = data.ExportModelDataFolder + "\\GuidStorage.xml";
    }

    internal bool StoreExportModelInformation(
      ExportVersionData exportVersionsData,
      ref ExportData data)
    {
      string exportModelDataFolder = data.ExportModelDataFolder;
      if (!Directory.Exists(exportModelDataFolder))
      {
        try
        {
          Directory.CreateDirectory(exportModelDataFolder);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = exportModelDataFolder;
        }
      }
      string modelSettingsFile = data.ExportModelSettingsFile;
      if (new ClassSerializer().ToXml((object) exportVersionsData, modelSettingsFile, false))
        return true;
      data.Errors.ErrorCode = ErrorCode.ExportSettingsStoringFailed;
      data.Errors.ErrorInfo = modelSettingsFile;
      return false;
    }

    private bool ReadVersions(object dataType, ref ExportData data, out List<object> list)
    {
      ClassSerializer classSerializer = new ClassSerializer();
      list = new List<object>();
      if (!Directory.Exists(data.ExportModelsFolder))
      {
        try
        {
          Directory.CreateDirectory(data.ExportModelsFolder);
        }
        catch (Exception ex)
        {
          data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
          data.Errors.ErrorInfo = data.ExportModelsFolder;
          return false;
        }
      }
      foreach (FileSystemInfo directory in new DirectoryInfo(data.ExportModelsFolder).GetDirectories())
      {
        string name = directory.Name;
        if (!(name == "Settings"))
        {
          this.GetModelSpecificData(name, ref data);
          string path = data.ExportModelsFolder + "\\" + name + "\\Data";
          string str = path + "\\Settings.xml";
          try
          {
            if (!Directory.Exists(path))
              Directory.CreateDirectory(path);
          }
          catch (Exception ex)
          {
            data.Errors.ErrorCode = ErrorCode.FolderCreationFailed;
            data.Errors.ErrorInfo = path;
            return false;
          }
          if (File.Exists(str) && classSerializer.FromXml(ref dataType, str) && !list.Contains(dataType))
            list.Add(dataType);
        }
      }
      return true;
    }
  }
}
