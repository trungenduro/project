﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.Constants
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

namespace IfcModelCollaboration
{
  internal class Constants
  {
    internal const string ApplicationVersion = "ApplicationVersion";
    internal const string BackSlash = "\\";
    internal const string Caches = "Caches";
    internal const string Checked = "Checked";
    internal const string Content = "Content";
    internal const string Data = "Data";
    internal const string DataInformation = "DataInformation";
    internal const string DateTimeUtc = "DateTimeUtc";
    internal const string DataInformationDotXml = "DataInformation.xml";
    internal const string DotDgn = ".dgn";
    internal const string DotDwg = ".dwg";
    internal const string Hierachy = "Hierarchy";
    internal const string DotTcZip = ".tcZip";
    internal const string DotTsfo = ".tsfo";
    internal const string ExportSoftware = "ExportSoftware";
    internal const string Grade = "Grade";
    internal const string Guids = "Guids";
    internal const string GuidStorage = "GuidStorage";
    internal const string DotIfc = ".ifc";
    internal const string Imperial = "Imperial";
    internal const string HierarchyName = "HierarchyName";
    internal const string IfcGuid = "IfcGuid";
    internal const string DotIfcZip = ".ifcZIP";
    internal const string Key = "Key";
    internal const string DotSkp = ".skp";
    internal const string DotXml = ".xml";
    internal const string Filter = "Filter";
    internal const string Folder = "Folder";
    internal const string Guid = "Guid";
    internal const string ImportSoftware = "ImportSoftware";
    internal const string KeepPrevious = "KeepPrevious";
    internal const string Links = "Links";
    internal const string LinkVersion = "LinkVersion";
    internal const string Location = "Location";
    internal const string Materials = "Materials";
    internal const string Minus = "-";
    internal const string Name = "Name";
    internal const string NameFull = "NameFull";
    internal const string Profiles = "Profiles";
    internal const string Settings = "Settings";
    internal const string SettingsDotXml = "Settings.xml";
    internal const string Software = "Software";
    internal const string Stored = "Stored";
    internal const string TeklaGuid = "TeklaGuid";
    internal const string Type = "Type";
    internal const string Value = "Value";
    internal const string Version = "Version";
    internal const string Versions = "Versions";
  }
}
