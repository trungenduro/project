﻿// Decompiled with JetBrains decompiler
// Type: IfcModelCollaboration.IfcModelCollaboration
// Assembly: IfcModelCollaboration, Version=2099.1.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4FD7DE9B-FBF7-4747-A620-F10F7C8F2B9D
// Assembly location: C:\TS_E3D\2.1\TS-E3D_Library\IfcModelCollaboration.dll

using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace IfcModelCollaboration
{
  public class IfcModelCollaboration
  {
    private readonly ExportModels exportModels;

    public IfcModelCollaboration()
    {
      if (this.exportModels != null)
        return;
      this.exportModels = new ExportModels();
    }

    public bool RemoveImportInstance(
      string rootfolder,
      SoftwareOptions softwareOption,
      string selectedModel)
    {
      return new FolderHierarchy().RemoveFolderHierarchy(rootfolder, IfcModelCollaboration.IfcModelCollaboration.Action.Import, softwareOption, selectedModel);
    }

    public List<ExportVersionData> GetIfcExportInformation(
      SoftwareOptions exportSoftware,
      SoftwareOptions importSoftware,
      string rootFolder,
      out ExportData data)
    {
      data = new ExportData();
      data.DataInformation = new DataInformation();
      data.Errors = new Errors();
      data.DataInformation.ExportSoftware = exportSoftware;
      data.DataInformation.ImportSoftware = importSoftware;
      data.RootFolder = rootFolder;
      ImportData importData = new ImportData();
      if (!new FolderHierarchy().HandleFolderHierarchy(rootFolder, IfcModelCollaboration.IfcModelCollaboration.Action.Export, ref importData, ref data))
        return (List<ExportVersionData>) null;
      if (string.IsNullOrEmpty(data.ExportModelsFolder))
        return (List<ExportVersionData>) null;
      List<object> list;
      if (!this.exportModels.GetExportModelsData((object) new ExportVersionData(), ref data, out list))
        return (List<ExportVersionData>) null;
      if (list == null)
        return new List<ExportVersionData>();
      return list.Cast<ExportVersionData>().ToList<ExportVersionData>();
    }

    public bool ExportToSoftwareFolders(
      SoftwareOptions exportSoftware,
      SoftwareOptions importSoftware,
      string rootFolder,
      ExportVersionData exportVersionData,
      out ExportData data)
    {
      data = new ExportData();
      data.DataInformation = new DataInformation();
      data.Errors = new Errors();
      data.DataInformation.ExportSoftware = exportSoftware;
      data.DataInformation.ImportSoftware = importSoftware;
      data.RootFolder = rootFolder;
      ImportData importData = new ImportData();
      if (!new FolderHierarchy().HandleFolderHierarchy(rootFolder, IfcModelCollaboration.IfcModelCollaboration.Action.Export, ref importData, ref data) || string.IsNullOrEmpty(data.ExportModelsFolder))
        return false;
      if (string.IsNullOrEmpty(exportVersionData.Folder))
        exportVersionData.Folder = rootFolder + "\\ExportTo" + importSoftware.ToString();
      exportVersionData.FolderAbsolute = exportVersionData.Folder;
      if (exportVersionData.Folder.StartsWith(".\\"))
        exportVersionData.FolderAbsolute = Path.Combine(data.RootFolder, exportVersionData.Folder.Remove(0, 2));
      if (exportVersionData.Folder.Contains(rootFolder))
        exportVersionData.Folder = exportVersionData.Folder.Replace(rootFolder, ".");
      return true;
    }

    public bool ExportToSoftwareStoreSettings(
      ExportVersionData exportVersionsData,
      ref ExportData data)
    {
      this.exportModels.GetModelSpecificData(exportVersionsData.Name, ref data);
      return this.exportModels.StoreExportModelInformation(exportVersionsData, ref data);
    }

    public bool CreateTempExportFolder(out string tempFolder)
    {
      return new Tools().CreateTempExportFolder(out tempFolder);
    }

    public bool ZipFiles(
      string tobezipped,
      string folder,
      string fileName,
      Dictionary<string, string> brepsDictionary,
      ref List<string> brepErrors,
      SoftwareOptions software,
      string extension,
      double revitVersion)
    {
      brepErrors = (List<string>) null;
      return new Tools().ZipFiles(tobezipped, folder, fileName, brepsDictionary, ref brepErrors, software, extension, revitVersion);
    }

    public bool ZipFilesToTekla(
      string tobezipped,
      string folder,
      string fileName,
      string extension)
    {
      return new Tools().ZipFilesToTekla(tobezipped, folder, fileName, extension);
    }

    public bool WriteDataInformationXml(
      SoftwareOptions exportSoftware,
      SoftwareOptions importSoftware,
      string folder,
      ref DataInformation dataInformation,
      ref Errors errors,
      bool isImperial = false)
    {
      dataInformation.ExportSoftware = exportSoftware;
      dataInformation.ImportSoftware = importSoftware;
      dataInformation.IsImperial = isImperial;
      return new DataInformationHandler().WriteDataInformation(folder, ref dataInformation, ref errors);
    }

    public string VerifyGuid(string text, string text2)
    {
      return new Tools().MakePacketUnique(text, text2);
    }

    public bool StoreGuids(ref ExportData data, Dictionary<string, string> nativeGuidifcGuid)
    {
      return new GuidHandler().StoreGuids(ref data, nativeGuidifcGuid);
    }

    public bool GetGuids(
      ExportData data,
      out Dictionary<string, string> nativeGuidifcGuid,
      out List<string> nativeGuidList)
    {
      return new GuidHandler().GetGuids(data, out nativeGuidifcGuid, out nativeGuidList);
    }

    public bool RemoveExportInstance(
      string rootfolder,
      SoftwareOptions softwareOption,
      string selectedModel)
    {
      return new FolderHierarchy().RemoveFolderHierarchy(rootfolder, IfcModelCollaboration.IfcModelCollaboration.Action.Export, softwareOption, selectedModel);
    }

    public bool CreateHierarchyXml(string folder, DataSet set)
    {
      string path2 = "Hierarchies.xml";
      return new XmlHandler().WriteDataSetToXml(Path.Combine(folder, path2), set);
    }

    private DataSet GetTwoVersionsChanges(
      SoftwareOptions software,
      string versionNewer,
      string versionOlder,
      string rootFolder,
      out ImportData data,
      string cacheFolder = ".",
      bool clearCaches = false,
      double similarity = 0.9)
    {
      DataSet dataSet = new DataSet();
      data = new ImportData();
      data.DataInformation = new DataInformation();
      data.Errors = new Errors();
      data.DataInformation.ExportSoftware = software;
      data.RootFolder = rootFolder;
      new Checking().CheckSimilarityValue(similarity, ref data);
      ExportData exportData = new ExportData();
      if (!new FolderHierarchy().HandleFolderHierarchy(data.RootFolder, IfcModelCollaboration.IfcModelCollaboration.Action.Import, ref data, ref exportData))
        return (DataSet) null;
      if (!string.IsNullOrEmpty(data.NewImportVersionFile))
        string.IsNullOrEmpty(data.PreviousImportVersionFile);
      return dataSet;
    }

    internal enum Action
    {
      Export,
      Import,
      Compare,
    }
  }
}
